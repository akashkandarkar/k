
public class EngineeringBook extends Book
{
	private String category;

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}
	
	public void DisplayGet() 
	{
		System.out.println("Book No.: "+this.getBookNo());
		System.out.println("Book Name "+this.getTitle());
		System.out.println("Category "+this.category);
		System.out.println("Author Name "+this.getAuthor());
		System.out.println("Price "+this.getPrice());
	}
}
