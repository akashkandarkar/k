package set;

import java.util.TreeSet;

import List.Emp;

@SuppressWarnings("unused")
public class TreeSetDemo {

	@SuppressWarnings({ "rawtypes" })
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		TreeSet ts=new TreeSet();
		//ts.add(true);
		//	ts.add(7);
		//	ts.add("Pogba");
		//	ts.add('K');
		//	ts.add(new Emp(7, "Rooney"));
		System.out.println(ts);

	}

}
