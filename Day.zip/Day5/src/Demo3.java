import java.util.Scanner;


public class Demo3 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int arr[]=new int[4];
		arr[0]=7;arr[1]=1;arr[2]=9;arr[3]=10;
		System.out.println("Enter the index");
		int idx;
		try {
			idx=sc.nextInt();
			System.out.println("Character at entered index is : "+arr[idx]);
			String str="Rooney";
			System.out.println("Enter the index");
			idx=sc.nextInt();
			System.out.println("Character at entered index is : "+str.charAt(idx));
		}

		catch(ArrayIndexOutOfBoundsException aie)
		{
			//System.err.println("Invalid index");
			System.err.println("Mitra tu chuklays");
		}

		catch(StringIndexOutOfBoundsException sie)
		{
			//System.err.println("String index is out of bounds");
			System.err.println("Parat chuklas");
		}

		catch (Exception e) 
		{
			System.err.println("Nakki tula ky zalay!!!");
		}
	}
}
