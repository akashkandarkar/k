package exceptions;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

@SuppressWarnings("unused")
public class Clinic {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Doctor d=new Doctor();
		//BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter degree of the doctor");
		try
		{
			//d.setDegree(sc.useDelimiter("\n").next());
			/*try 
			{
				d.setDegree(br.readLine());
			} 
			catch (IOException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
			d.setDegree(sc.nextLine());
		}
		catch (DoctorException e) 
		{
			// TODO Auto-generated catch block
			System.err.println(e);
		}
		System.out.println("Enter doctor's name");
		d.setName(sc.useDelimiter("\n").next());
		System.out.println(d);

	}

}
