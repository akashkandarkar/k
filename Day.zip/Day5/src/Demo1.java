import java.util.Scanner;


public class Demo1 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the numerator : ");
		int num=sc.nextInt();
		System.out.println("Enter the denominator : ");
		int den=sc.nextInt();	
		
		try 
		{
			float ans=num/den;
			System.out.println("Result is : "+ans);
		}
		
		catch (ArithmeticException ae) 
		{
			// TODO: handle exception
			System.err.println("Divide by 0 is not possible");
		}
		
		finally
		{
			System.err.println("Divide by 0 is not possible");
		}
	}
}
