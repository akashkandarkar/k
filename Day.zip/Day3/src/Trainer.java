
public class Trainer extends Person {

	private int no_of_skill;
	private int expInYrs;
	
	
	
	public Trainer(String fname, String lname, String address, int no_of_skill,int expInYrs) 
	{
		super(fname, lname, address);
		this.no_of_skill = no_of_skill;
		this.expInYrs = expInYrs;
	}

	public void inTrainer() 
	{
		System.out.println("Trainer method");
	}

	@Override
	public void showDetails() 
	{
		// TODO Auto-generated method stub
		System.out.println("First Name : "+this.fname+"\nLast Name : "+this.lname+"\nAddress : "+this.address+"\n No of skills : "+no_of_skill+"\nExperience : "+expInYrs);
	}
	
	

}
