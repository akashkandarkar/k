
public class TLS 
{

	public static void main(String[] args) 
	{
		Trainer t=new Trainer("Paul", "Pogba", "Marseille", 2, 5);
		t.showDetails();
		
		//UPcasting
		Person p=new Trainer("Wayne", "Rooney", "Liverpool", 4, 12);
		p.showDetails();
		
		//DOWNcasting
		Trainer t1=(Trainer) p;
		t1.inTrainer();
	}
}
