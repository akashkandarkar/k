import java.util.Date;


public class TestInheritance {

	@SuppressWarnings("deprecation")
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Date d=new Date((2015-1900),(10-1),26);
		/*Associate a=new Associate(101, "Rooney", d);
		a.showData();
		System.out.println(a.toString());*/
		ELITian e=new ELITian(101, "Pogba", d, 1777, "TUS-05");
		System.out.println(e.toString());
	}

}
