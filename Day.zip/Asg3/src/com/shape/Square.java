package com.shape;

import java.util.Scanner;

public class Square implements Polygon
{
	Scanner sc=new Scanner(System.in);
	float side;
	float res,ans;

	@Override
	public void calcArea() 
	{
		// TODO Auto-generated method stub
		System.out.print("Enter the side of square : ");
		side=sc.nextFloat();
		res=side*side;
	}

	@Override
	public void calcPeri() 
	{
		// TODO Auto-generated method stub
		ans=side+side;
	}

	@Override
	public String toString() {
		return "Square [Area=" + res + ", Perimeter=" + ans + "]";
	}
}
