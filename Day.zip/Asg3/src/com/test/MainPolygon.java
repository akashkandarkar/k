package com.test;

import com.shape.*;

public class MainPolygon
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Square sq=new Square();
		sq.calcArea();
		sq.calcPeri();
		System.out.println(sq.toString());
		Rectangle r=new Rectangle();
		r.calcArea();
		r.calcPeri();
		System.out.println(r.toString());
	}
}
