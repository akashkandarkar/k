import java.util.Date;


public abstract class Medicine 
{
	abstract void displayLabel();
	private int price;
	private Date exdate;
	
	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public Date getExdate() {
		return exdate;
	}

	public void setExdate(Date exdate) {
		this.exdate = exdate;
	}
	
}
