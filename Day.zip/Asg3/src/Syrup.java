
public class Syrup extends Medicine
{

	@Override
	void displayLabel() 
	{
		// TODO Auto-generated method stub
		System.out.println("Do not add water");
		
	}

}
