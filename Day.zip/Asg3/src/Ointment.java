
public class Ointment extends Medicine
{

	@Override
	void displayLabel() 
	{
		// TODO Auto-generated method stub
		System.out.println("For external use only");
	}
	
}
