package D3;

import java.util.Scanner;

public class Delivery 
{

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the number of orders : ");
		int n=sc.nextInt();
		Pizza p[]=new Pizza[n];
		for (int i=0;i<p.length;i++)
		{
			System.out.print("Enter the Italian/Mexican pizza : ");
			String name=sc.next();
			System.out.print("Enter veg/nonveg pizza : ");
			String type=sc.next();
			System.out.print("Enter size of pizza : ");
			String size=sc.next();
			System.out.print("Enter toppings : ");
			String toppings=sc.next();
			p[i]=new ItalianPizza(type, name, size, toppings);
		}
		for (int i=0;i<p.length;i++)
		{
			System.out.println(p[i].toString());
		}
	}
}
