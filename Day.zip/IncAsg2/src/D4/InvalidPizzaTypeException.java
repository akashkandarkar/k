package D4;

@SuppressWarnings("serial")
public class InvalidPizzaTypeException extends Exception
{

	public InvalidPizzaTypeException(String message)
	{
		super(message);
	}
	
}
