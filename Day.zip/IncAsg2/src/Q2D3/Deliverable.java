package Q2D3;

public interface Deliverable 
{
	int deliveryAreaLimit=2;
	public boolean delivery();

}
