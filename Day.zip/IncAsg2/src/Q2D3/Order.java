package Q2D3;

import java.util.Date;

public class Order implements Deliverable
{
	int orderNo;
	Date orderDate;
	int cost;
	String custName;		
	String custAddress;
	int approxDistance;

	public Order(int orderNo, Date orderDate, int cost, String custName,String custAddress, int approxDistance) 
	{
		this.orderNo = orderNo;
		this.orderDate = orderDate;
		this.cost = cost;
		this.custName = custName;
		this.custAddress = custAddress;
		this.approxDistance = approxDistance;
	}

	@Override
	public boolean delivery() 
	{
		if(approxDistance>deliveryAreaLimit)
		{
			System.out.println("Home delivery not available");
			return false;
		}
		else
		{
			return true;
		}
	}

}
