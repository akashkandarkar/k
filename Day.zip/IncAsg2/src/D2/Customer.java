package D2;

import java.util.Date;

public class Customer
{
	static
	{
		billno=0;
	}
	
	int custNo;
	String custName;	
	String custAddr;
	static int billno;
	
	public void init() 
	{
		this.custNo=100;
		this.custName="Rooney";
		this.custAddr="Liverpool";
	}

	@SuppressWarnings("deprecation")
	public void display() 
	{
		Date d=new Date();
		d.setDate(26);
		d.setMonth(4-1);
		d.setYear(2017-1900);
		Customer.print_bill();
		System.out.println("Bill No : "+billno+"               "+"Date : "+d);
		System.out.println("Customer : "+this.custName);
		System.out.println("Address : "+this.custAddr);
		//System.out.println("Customer no : "+this.custNo+" Name "+this.custName+" Address : "+this.custAddr);
	}
	
	public static void print_bill()
	{
		billno++;
	}

	public int getCustNo() {
		return custNo;
	}

	public void setCustNo(int custNo) {
		this.custNo = custNo;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getCustAddr() {
		return custAddr;
	}

	public void setCustAddr(String custAddr) {
		this.custAddr = custAddr;
	}
	
	public void addCustomer(Customer c) 
	{
		this.custNo=c.custNo;
		this.custName=c.custName;
		this.custAddr=c.custAddr;
	}
	
	
}
