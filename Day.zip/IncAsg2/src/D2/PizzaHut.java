package D2;

import java.util.Scanner;

public class PizzaHut {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		/*Customer c=new Customer();
		c.init();
		c.display();
		c.setCustNo(101);
		c.setCustName("Mkhitaryan");
		c.setCustAddr("Armenia");
		c.display();*/
		
		Customer c[]=new Customer[5];
		for (int i=0;i<c.length;i++) 
		{
			c[i]=new Customer();
			System.out.print("Enter customer no. : ");
			c[i].setCustNo(sc.nextInt());
			System.out.print("Enter name ");
			c[i].setCustName(sc.next());
			System.out.print("Enter address ");
			c[i].setCustAddr(sc.next());
			c[i].addCustomer(c[i]);
		}
		for (int i=0;i<c.length;i++) 
		{
			c[i].display();
		}
	}

}
