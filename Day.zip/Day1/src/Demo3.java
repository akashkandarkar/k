
public class Demo3 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		int arr[]=new int[5];
		arr[0]=7;
		arr[1]=18;
		arr[2]=27;
		arr[3]=32;
		arr[4]=44;
		for (int i = 0; i < arr.length; i++)
		{
			System.out.println(arr[i]);
		}
	}

}