package Q7;

import java.util.Date;
import java.util.Hashtable;

public class Shop {

	@SuppressWarnings({ "deprecation" })
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Date d=new Date((2017-1900), (11-1), 27);
		try
		{
			Order o1=new Order("O001", "Man Utd", d);
			Customer c1=new Customer(22, "Mkhitaryan");
			Hashtable<Customer,Order> hs1=new Hashtable<Customer, Order>();
			hs1.put(c1, o1);
			MyShopping ms1=new MyShopping(hs1);
			ms1.setRecord("records.dat");
			ms1.getRecord("records.dat");
		}
		catch (OrderException e)
		{
			System.err.println(e.getMessage());
		}

	}

}
