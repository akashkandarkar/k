package Q7;

import java.util.Date;

public class Order
{
	private String orderId;
	private String orderDetails;
	private Date orderDate;

	public Order(String orderId, String orderDetails, Date orderDate) throws OrderException
	{
		char ch=orderId.charAt(0);
		if(((ch=='O')||(ch=='o'))&&orderId.length()>=3)
		{
			this.orderId = orderId;
			this.orderDetails = orderDetails;
			this.orderDate = orderDate;
		}
		else
		{
			throw new OrderException("Order ID should start with O");
		}
	}

	public String getOrderId() 
	{
		return orderId;
	}

	public String getOrderDetails() 
	{
		return orderDetails;
	}

	public Date getOrderDate() 
	{
		return orderDate;
	}

	@Override
	public String toString() 
	{
		return "Order Id : " + orderId + ", Order Details : " + orderDetails+ " Order Date : " + orderDate+"\n";
	}
	
}
