
public class MyThreadInt implements Runnable
{
	/*String name;
	
	public MyThreadInt(String name) 
	{
		// TODO Auto-generated constructor stub
		this.name=name;
	}*/

	@Override
	public void run() 
	{
		// TODO Auto-generated method stub
		System.out.println("Hello, this is "+Thread.currentThread().getName());

	}

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Thread t1=new Thread(new MyThreadInt(),"t1");
		Thread t2=new Thread(new MyThreadInt(),"t2");
		Thread t3=new Thread(new MyThreadInt(),"t3");
		/*Runnable r1=new MyThreadInt();
		Thread t1=new Thread(r1,"t1");
		Runnable r2=new MyThreadInt();
		Thread t2=new Thread(r2,"t2");
		Runnable r3=new MyThreadInt();
		Thread t3=new Thread(r3,"t3");*/
		t1.start();
		t2.start();
		t3.start();

	}

}
