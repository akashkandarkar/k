
public class MyThread extends Thread 
{	
	public MyThread(String name) 
	{
		this.setName(name);
	}

	@Override
	public void run() 
	{
		// TODO Auto-generated method stub
		System.out.println("Hello, this is "+this.getName());
	}
	
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		MyThread th1=new MyThread("thread1");
		MyThread th2=new MyThread("thread2");
		MyThread th3=new MyThread("thread3");
		th1.setPriority(Thread.MAX_PRIORITY);
		th2.setPriority(Thread.NORM_PRIORITY);
		th3.setPriority(Thread.MIN_PRIORITY);
		th1.start();
		th2.start();
		th3.start();
	}
	
}
