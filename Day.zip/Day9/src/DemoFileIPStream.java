import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class DemoFileIPStream
{

	public static void main(String[] args)
	{
		//File f=new File("C:\\Users\\ct0t1868\\Desktop\\Java\\KP\\Day\\Day3\\src\\Emp.java");
		File f=new File("data.txt");
		try
		{
			FileInputStream f1=new FileInputStream(f);
			int ch;
			while((ch=f1.read())!=-1)
			{
				System.out.print((char)ch);
			}
			f1.close();
		} 
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		} catch (IOException e) 
		{
			e.printStackTrace();
		}

	}

}
