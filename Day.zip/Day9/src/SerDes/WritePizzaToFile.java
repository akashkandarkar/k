package SerDes;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class WritePizzaToFile 
{

	public static void main(String[] args) 
	{
		//1. Create object

		Pizza p1=new Pizza("Deluxe Margarita", 7);

		//2.Write an object into file - FOS, DOS

		try 
		{
			FileOutputStream fos=new FileOutputStream("pizzainfo.txt");
			DataOutputStream dos=new DataOutputStream(fos);
			dos.writeBytes(p1.toString());
			dos.close();
			fos.close();

			//3.Read an object from the file - FIS, DIS
			FileInputStream fis=new FileInputStream("pizzainfo.txt");
			DataInputStream dis=new DataInputStream(fis);
			int ch;
			while((ch=dis.read())!=-1)
			{
				System.out.print((char) ch);
			}
			

			//4. Closing all the resources
		}
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		}
		catch (IOException e) 
		{
			e.printStackTrace();
		}



	}

}
