package SerDes;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Pizza implements Serializable
{
	private String name;
	private int quantity;
	
	public Pizza(String name, int quantity)
	{
		super();
		this.name = name;
		this.quantity = quantity;
	}

	@Override
	public String toString()
	{
		//return "Pizza Name : " + name + "| quantity=" + quantity;
		return name+" | "+quantity;
	}
	
	
}
