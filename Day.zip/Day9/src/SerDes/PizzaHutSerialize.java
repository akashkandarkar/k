package SerDes;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class PizzaHutSerialize 
{

	public static void main(String[] args) 
	{
		//1. Create object

		Pizza p1=new Pizza("Deluxe Margarita", 7);

		//2. Serialization - FOS,OOS

		try 
		{
			FileOutputStream fos=new FileOutputStream("pizzainfo.txt");
			ObjectOutputStream oos=new ObjectOutputStream(fos);
			oos.writeObject(p1);
			fos.close();
			oos.close();

			//3. De-serialization - FIS,OIS

			FileInputStream fis=new FileInputStream("pizzainfo.txt");
			ObjectInputStream ois=new ObjectInputStream(fis);
			Pizza p2=(Pizza) ois.readObject();
			System.out.println(p2);
			fis.close();
			ois.close();
		} 
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		catch (ClassNotFoundException e)
		{
			e.printStackTrace();
		}

	}

}
