package Q4;

public class Counter extends Thread
{
	Storage t1;
	public void run()
	{
		
		t1.setCount(t1.getCount()+1);
	}
}
