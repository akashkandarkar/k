package Q4;

public class Main {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Storage t3=new Storage();
		Counter t4=new Counter();
		Printer t5=new Printer();
		t4.start();
		t5.start();
	}

}
