package Q4;

public class Storage extends Thread
{
	public int count=0;

	public void setCount(int count) {
		this.count = count;
	}

	public int getCount() {
		return count;
	}

	public Storage(int count) {
		super();
		this.count = count;
	}
	
}
