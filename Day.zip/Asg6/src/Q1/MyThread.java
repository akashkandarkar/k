package Q1;

public class MyThread extends Thread 
{

	@Override
	public void run() 
	{
		// TODO Auto-generated method stub
		System.out.println("Hello");
		System.out.println("World");
		System.out.println("!!!!");
	}
	

}
