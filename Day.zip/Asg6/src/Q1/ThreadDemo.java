package Q1;

public class ThreadDemo 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		MyThread th1=new MyThread();
		MyThread th2=new MyThread();
		MyThread th3=new MyThread();
		th1.start();
		th2.start();
		th3.start();
	}
}
