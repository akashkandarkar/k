package Q2;

public class MyThread implements Runnable 
{

	@Override
	public void run() 
	{
		// TODO Auto-generated method stub
		for(int i=1;i<6;i++)
		{
			System.out.print(i);
		}
		System.out.println();
	}

}
