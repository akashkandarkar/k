package D1;

import java.util.Arrays;
import java.util.Scanner;

public class FlashCard 
{
	private String subject;
	private String question;
	private String answer;
	
	public String getSubject() {
		return subject;
	}
	
	public void setSubject(String subject) {
		this.subject = subject;
	}
	
	public String getQuestion() {
		return question;
	}
	
	public void setQuestion(String question) {
		this.question = question;
	}
	
	public String getAnswer() {
		return answer;
	}
	
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	
	public void sort(FlashCard fc) 
	{
		this.sort(fc);
		/*int r=(this.subject.compareToIgnoreCase(fc.subject));
		if(r<0)
		{
			this.sort(fc);
		}*/
	}
	
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		FlashCard fc[]=new FlashCard[5];
		for (int i = 0; i < fc.length; i++) 
		{
			fc[i]=new FlashCard();
			System.out.println("Enter subject : ");
			fc[i].setSubject(sc.next());
			System.out.println("Enter question : ");
			fc[i].setQuestion(sc.next());
			System.out.println("Enter answer : ");
			fc[i].setAnswer(sc.next());
		}
		
		for (int i = 0; i < fc.length; i++) 
		{
			System.out.println((i+1)+"  "+fc[i].getSubject());
			System.out.println((i+1)+"  "+fc[i].getQuestion());
			System.out.println((i+1)+"  "+fc[i].answer);
		}
	}
}
