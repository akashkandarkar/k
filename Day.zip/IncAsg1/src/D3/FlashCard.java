package D3;

public class FlashCard extends Card
{

	public FlashCard(String subject, String question, String answer) 
	{
		this.setSubject(subject);
		this.setQuestion(question);
		this.setAnswer(answer);
	}
	
	public void displayCard()
	{
		System.out.println(this.getSubject()+this.getQuestion()+this.getAnswer());
	}
	
}