package D3;

public class FlashCardsData implements CardSearchable 
{
	FlashCard fc[]=new FlashCard[5];
	@Override
	public Card searchCard(String sub) 
	{
		// TODO Auto-generated method stub
		return null;
	}

}
