package Q4;

import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class WriteEmployee
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the number of employees to be entered : ");
		int n=sc.nextInt();
		Employee e[]=new Employee[n];
		for (int i=0;i<e.length;i++) 
		{
			System.out.print("Enter employee ID : ");
			int id=sc.nextInt();
			System.out.print("Enter employee name : ");
			String name=sc.next();
			System.out.print("Enter salary : ");
			int sal=sc.nextInt();
			System.out.println();
			e[i]=new Employee(id, name, sal);
		}
		
		try 
		{
			FileOutputStream fos=new FileOutputStream("emp.txt");
			DataOutputStream dos=new DataOutputStream(fos);
			for (int i=0;i<e.length;i++)
			{
				dos.writeBytes(e[i].toString());
				dos.writeBytes("\n");
			}
			FileInputStream fis=new FileInputStream("emp.txt");
			int ch;
			while((ch=fis.read())!=-1)
			{
				System.out.print((char) ch);
			}
			fis.close();
			dos.close();
			fos.close();
		} 
		catch (FileNotFoundException e1)
		{
			e1.printStackTrace();
		} 
		catch (IOException e1)
		{
			e1.printStackTrace();
		}
	}
}
