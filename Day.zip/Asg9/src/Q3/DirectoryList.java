package Q3;

import java.io.File;
import java.util.Scanner;

public class DirectoryList 
{

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the name of directory : ");
		String dir=sc.next();
		File f=new File(dir);
		if (f.isDirectory())
		{
			String det[]=f.list();
			for (int i=0;i<det.length;i++) 
			{
				System.out.println(det[i]);
			}
		}
		else
		{
			System.out.println("Invalid directory");
		}
	}

}
