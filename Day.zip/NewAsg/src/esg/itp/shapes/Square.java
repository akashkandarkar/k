package esg.itp.shapes;

public class Square implements Polygon 
{
	double side;

	public Square(double side) {
		super();
		this.side = side;
	}

	@Override
	public void calcArea() 
	{
		// TODO Auto-generated method stub
		//Polygon.area=side*side;

	}

	@Override
	public void calcPeri() 
	{
		// TODO Auto-generated method stub
		//perimeter=2*side;

	}

	@Override
	public void display() 
	{
		// TODO Auto-generated method stub

	}

}
