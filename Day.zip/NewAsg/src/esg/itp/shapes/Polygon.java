package esg.itp.shapes;

public interface Polygon
{
	double area=0;	
	double perimeter=0;
	
	void calcArea( );
	void calcPeri( );
	void display( );
}
