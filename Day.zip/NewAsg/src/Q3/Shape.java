package Q3;

public interface Shape
{
	public void draw();
	public void rotate();

}
