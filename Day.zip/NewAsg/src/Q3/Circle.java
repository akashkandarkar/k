package Q3;

public class Circle implements Shape {

	@Override
	public void draw() 
	{
		// TODO Auto-generated method stub
		System.out.println("Circle drawn");
	}

	@Override
	public void rotate() 
	{
		// TODO Auto-generated method stub
		System.out.println("Circle rotated");
	}

}
