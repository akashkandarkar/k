package Q3;

public class TestShape
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Shape c=new Circle();
		c.draw();
		c.rotate();
		Shape r=new Rectangle();
		r.draw();
		r.rotate();

	}

}
