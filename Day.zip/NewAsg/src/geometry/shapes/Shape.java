package geometry.shapes;

public interface Shape 
{
	void draw( );
	void scale( );
}
