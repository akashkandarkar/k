package Q7;

public interface AccountInter 
{
	public void create( int accNo,  String name, double accBal );
	public double delete( int accNo );
	public void print ( int accNo );
}
