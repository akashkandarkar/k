package Q7;

import java.util.Scanner;

public class AccountDemo 
{

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		Account a[]=new Account[2];
		
		for (int i=0;i<a.length;i++) 
		{
			System.out.print("Enter account number of "+(i+1)+" person : ");
			int accno=sc.nextInt();
			System.out.print("Enter name of "+(i+1)+" person : ");
			String name=sc.next();
			System.out.print("Enter account balance of "+(i+1)+" person : ");
			int bal=sc.nextInt();
			a[i]=new Account();
			a[i].create(accno,name,bal);
		}
		
		System.out.print("Enter account number to print : ");
		int ch1=sc.nextInt();
		for (int i=0;i<a.length;i++) 
		{
			if(a[i].getAccNo()==ch1)
			{
				a[i].print(ch1);
			}
		}
		
		System.out.print("Enter account number to delete : ");
		int ch2=sc.nextInt();
		for (int i=0;i<a.length;i++) 
		{
			if(a[i].getAccNo()==ch2)
			{
				double ret=a[i].delete(ch2);
				if(ret==0)
				{
					System.out.println("Account successfully deleted");
				}
				else
				{
					System.out.println("Error in deletion");
				}
				a[i].print(ch2);
			}
		}
	}

}
