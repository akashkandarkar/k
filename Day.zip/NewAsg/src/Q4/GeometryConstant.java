package Q4;

public interface GeometryConstant 
{
	final double PI = 3.142;
}
