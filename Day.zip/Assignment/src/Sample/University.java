package Sample;

import java.util.Scanner;

public class University 
{
	static int count=0;
	private static Professor professor=new Professor();
	Exam exam=new Exam();
	static Course course=new Course();
	static boolean flag=false;

	public boolean studentVerificationProcess(Student student)
	{
		if(Registrar.registerStudent(student))
		{
			System.out.println(student.getName()+" you are registered successfully, Welcome to our university");
			count++;
			System.out.println("Your student ID is "+count);
			return true;
		}
		else
		{
			System.out.println("Registration Failed!!!");
			return false;
		}

	}

	public void writeExamGetResult(Exam exam) 
	{
		int marks=professor.evaluatingPaper(exam);
		exam.setMarks(marks);
	}

	public void studentAdmission(Student student, Course course) 
	{
		System.out.println(student.getName()+" registered for "+course.getName());
	}

	public void studentCertificationProcess(Student student, Course course)
	{
		if(studentVerificationProcess(student))
		{
			studentAdmission(student, course);
		}
		else
		{
			flag=true;
		}
	}

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Student st=new Student();
		System.out.println("Enter student name : ");
		st.setName(sc./*useDelimiter("\n").*/next());
		System.out.println("Enter student age : ");
		st.setAge(sc.nextInt());
		System.out.println("Enter Student Marks : ");
		st.setPreviousMarks(sc.nextInt());
		System.out.println("Enter course ID : ");
		course.setId(sc.nextInt());
		System.out.println("Enter course Name : ");
		course.setName(sc/*.useDelimiter("\n")*/.next());
		System.out.println("Enter course duration : ");
		course.setDuration(sc.nextInt());
		System.out.println("Enter professor Name : ");
		professor.setName(sc/*.useDelimiter("\n")*/.next());

		System.out.println("Student "+st.getName()+" applied for University");

		University u =new University();
		u.studentCertificationProcess(st, course);

		if(flag==false)
		{
			Exam e=new Exam();
			e.setId(course.getId());
			e.setName(course.getName());

			professor.setStudent(st);
			professor.teaches(course);
			professor.conductingExam(e);
			u.writeExamGetResult(e);
			if(e.getMarks()>80)
			{
				System.out.println(st.getName()+" your marks are above 80%");
				System.out.println(st.getName()+" your a "+course.getName()+" professional certified");
			}
			else
			{
				System.out.println(st.getName()+" your marks are below 80%");
			}
		}
	}

}
