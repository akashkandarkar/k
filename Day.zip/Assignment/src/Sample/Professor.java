package Sample;

public class Professor 
{
	private String name;
	private Student student;
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public Student getStudent() {
		return student;
	}
	
	public void setStudent(Student student) {
		this.student = student;
	}
	
	public void teaches(Course course) 
	{
		System.out.println(this.name+" is teaching "+course.getName()+" course to "+student.getName());
	}
	
	public void conductingExam(Exam exam) 
	{
		System.out.println("Professor "+this.name+" is counducting "+exam.getName()+" paper");
	}
	
	public int evaluatingPaper(Exam exam)
	{
		System.out.println(this.name+" is evaluating "+student.getName()+" "+exam.getName()+" exam paper");
		return 85;
	}
}
