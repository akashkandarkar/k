package Q2;

import java.util.*;
/*import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;*/
import java.util.Map.Entry;

public class Student 
{	
	private HashMap<String, String> empNames=new HashMap<String, String>();

	public void setNames(String rollNo, String name) 
	{
		empNames.put(rollNo, name);
	}

	@SuppressWarnings("rawtypes")
	public void printNames( )
	{
		/*Enumeration e = Collections.enumeration(empNames.values());
		Enumeration e1 = Collections.enumeration(empNames.keySet());
		while(e.hasMoreElements()&&e1.hasMoreElements())
		{
			System.out.println(e.nextElement()+"  "+e1.nextElement());
		}*/
		//	System.out.println(empNames.values());

		Iterator i=empNames.entrySet().iterator();
		while(i.hasNext())
		{
			Map.Entry me=(Entry) i.next();
			System.out.println(me.getKey());
			System.out.println(me.getValue());
		}
	}

	public void getName( String key )
	{
		String name=empNames.get(key);
		System.out.println("The name with roll no : "+key+" is : "+name);
	}

	public void printNamesKeySet( )
	{
		System.out.println(empNames);
	}

	public void printSize( )
	{
		System.out.println("The size of hashmap is "+empNames.size());
	}

	public void remove( String key )
	{
		empNames.remove(key);
	}

}
