package Q5;

import java.util.Comparator;

@SuppressWarnings("rawtypes")
public class Student implements Comparator
{
	private int rollNo;
	private String name;
	
	public Student(int rollNo, String name) 
	{
		this.rollNo = rollNo;
		this.name = name;
	}
	
	@Override
	public String toString() 
	{
		return "\nRollNo =" + rollNo + ", name=" + name;
	}

	@Override
	public int compare(Object obj0, Object obj1) 
	{
		Student s1=(Student) obj0;
		Student s2=(Student) obj1;
		int var=s1.name.compareTo(s2.name);
		if(var<0)
			return -1;
		else if(var>0)
			return 1;
		else
			return 0;
	}
	
	/*@Override
	public int compare(Object obj0, Object obj1)
	{
		// TODO Auto-generated method stub
		Student s1=(Student) obj0;
		Student s2=(Student) obj1;
		if(s1.rollNo < s2.rollNo)
			return -1;
		else if(s1.rollNo > s2.rollNo)
			return 1;
		else
		return 0;
	}*/

}
