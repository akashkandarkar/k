package Q4;

import java.util.ArrayList;
import java.util.Collections;

public class StudentSortDemo 
{

	@SuppressWarnings("unchecked")
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Student r=new Student(1, "Rooney");
		Student p=new Student(2, "Pogba");		
		Student i=new Student(3, "Ibrahimovic");
		Student m=new Student(4, "Mkhitaryan");
		Student d=new Student(5, "De Gea");
		
		ArrayList<Student> als=new ArrayList<Student>();
		
		als.add(m);
		als.add(r);
		als.add(i);
		als.add(d);
		als.add(p);
		System.out.println(als);
		
		//ArrayList<Student> als1=new ArrayList<Student>();
		Collections.sort(als);
		System.out.println(als);
	}

}
