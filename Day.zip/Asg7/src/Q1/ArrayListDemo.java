package Q1;

public class ArrayListDemo 
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Student s=new Student();
		s.setName("Rooney");
		s.setName("Ibrahimovic");
		s.setName("Pogba");
		s.setName("Mkhitaryan");
		s.setName("De Gea");
		s.setName("Mata");
		s.printName();
		s.searchName(5);
		s.searchName("Mkhitaryan");
		s.removeName("Mata");
		s.printName();
	}

}
