
public class Q5 
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		String str="Rooney Pogba Ibrahimovic Mkhitaryan Martial Ronaldo";
		String str1[]=str.split(" ");
		for(int k=0;k<str1.length-1;k++)
		{
			for(int m=(str1[k].length()-1),n=(str1[k+1].length()-1);m>=0&&n>=0;m--,n--)
			{
				if (str1[k].charAt(m)>str1[k+1].charAt(n))
				{
					String temp=str1[k];
					str1[k]=str1[k+1];
					str1[k+1]=temp;
					break;
				}
			}
		}
		
		for(int i=0;i<str1.length;i++)
		{
			String str2[]=str1[i].split("");
			for(int j=str2.length-1;j>=0;j--)
			{
				System.out.print(str2[j]);
			}
			System.out.println();
		}

	}

}
