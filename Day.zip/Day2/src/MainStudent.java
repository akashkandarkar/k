
public class MainStudent 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Student st1=new Student();
		st1.showStudent();
		
		Student st2=new Student(7,"Ronaldo");
		st2.showStudent();
		
		int roll=st2.getRollno();
		String name=st2.getSname();
		System.out.println("Using getter method");
		System.out.println("Roll No : "+roll);
		System.out.println("Name : "+name);
		
		System.out.println("Using getter method direct");
		System.out.println("Roll No : "+st2.getRollno());
		System.out.println("Name : "+st2.getSname());

	}

}
