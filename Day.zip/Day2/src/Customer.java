
public class Customer 
{
	private String custID;
	private String custName;
	private int custMobile;

	public static int count;
	
	static
	{
		System.out.println("In static block");
		count=0;
	}

	public Customer() 
	{
		count++;
		System.out.println("In default constructor.....!!!");
	}

	public Customer(String custID, String custName, int custMobile) 
	{
		System.out.println("In parameterized constructor......!!!!");
		this.custID = custID;
		this.custName = custName;
		this.custMobile = custMobile;
		count++;
	}

	public static void showcount() 
	{
		System.out.println(count);
	}
	
	@SuppressWarnings("static-access")
	public void showCustDetails() 
	{
		System.out.println(this.count);
		System.out.println(this.custID);
		System.out.println(this.custName);
		System.out.println(this.custMobile);
	}

}
