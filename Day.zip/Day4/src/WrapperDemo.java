
public class WrapperDemo
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		//AutoBoxing
		Integer i=new Integer(7);
		Character ch=new Character('K');
		Float f=new Float(2.7f);
		
		//Unboxing
		System.out.println(i.intValue());
		System.out.println(ch.charValue());
		System.out.println(f.floatValue());

	}

}
