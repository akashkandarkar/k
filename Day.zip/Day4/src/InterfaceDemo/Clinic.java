package InterfaceDemo;

public class Clinic {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Doctor d=new Doctor();
		d.getData();
		d.putData();
		System.out.println(d.hashCode());
	}

}
