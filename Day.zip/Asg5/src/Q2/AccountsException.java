package Q2;

@SuppressWarnings("serial")
public class AccountsException extends Exception 
{
	//1. toString
	
	
	//2. default constructor
	
	
	//3. parameterized constructor taking String argument
	public AccountsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
		
	}

}
