package Q2;

public class Accounts
{
	String AccId;
	String AccType;
	Exception AccountId_exception;
	
	public Accounts(String accId, String accType) throws AccountsException {
		super();
		if(accId.startsWith("ACC")&&accId.length()==6)
		{
			AccId = accId;
		}
		else
		{
			throw new AccountsException("Account Id is invalid");
		}
		if(accType.equalsIgnoreCase("Savings")||accType.equalsIgnoreCase("Current"))
		{
			AccType = accType;
		}
		else
		{
			throw new AccountsException("Invalid account type");
		}
	}
	
	public String getAccId() 
	{
		return AccId;
	}
	public void setAccId(String accId) throws AccountsException
	{
		if(accId.startsWith("ACC")&&accId.length()==6)
		{
			AccId = accId;
		}
		else
		{
			throw new AccountsException("Account Id is invalid");
		}
	}
	public String getAccType()
	{
		return AccType;
	}
	public void setAccType(String accType) throws AccountsException 
	{
		if(accType.equalsIgnoreCase("Savings")||accType.equalsIgnoreCase("Current"))
		{
			AccType = accType;
		}
		else
		{
			throw new AccountsException("Invalid account type");
		}
	}
	
	@Override
	public String toString() 
	{
		return "Accounts [AccId=" + AccId + ", AccType=" + AccType + "]";
	}
	
}
