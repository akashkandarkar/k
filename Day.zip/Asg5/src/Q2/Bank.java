package Q2;

import java.util.Scanner;

public class Bank 
{

	@SuppressWarnings("unused")
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		/*Accounts a=new Accounts();
		try 
		{
			System.out.println("Enter the account number");
			a.setAccId(sc.next());
		}
		catch (AccountsException e) 
		{
			// TODO Auto-generated catch block
			System.err.println(e.getMessage());
		}
		
		try
		{
			System.out.println("Enter account type");
			a.setAccType(sc.next());
		}
		catch (AccountsException e) 
		{
			// TODO Auto-generated catch block
			System.err.println(e.getMessage());
		}
		System.out.println(a.toString());*/
		
		try
		{
		Accounts a=new Accounts(sc.next(), sc.next());
		}
		catch (AccountsException e)
		{
			System.err.println(e.getMessage());
		}
	}
}
