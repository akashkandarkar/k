import java.util.Scanner;


public class Q1 {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int arr[]=new int[10];
		System.out.println("Enter 10 numbers");
		for (int i = 0; i < arr.length; i++) 
		{
			arr[i]=sc.nextInt();
		}
		System.out.println("Enter the index");
		int inx=0;
		try 
		{
			inx=sc.nextInt();
			System.out.println("Number is "+arr[inx]);
		}
		catch (ArrayIndexOutOfBoundsException ae) 
		{
			// TODO: handle exception
			System.err.println("Array out of bounds");
		}

	}

}
