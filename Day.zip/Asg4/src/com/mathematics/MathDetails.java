package com.mathematics;

import java.util.Scanner;

public class MathDetails implements Maths 
{
	Scanner sc=new Scanner(System.in);

	@Override
	public void sine() 
	{
		// TODO Auto-generated method stub
		System.out.println("Enter a number : ");
		double res=Math.sin(sc.nextDouble());
		System.out.println("Sine of number is : "+res);

	}

	@Override
	public void cosine()
	{
		// TODO Auto-generated method stub
		System.out.println("Enter a number : ");
		double res=Math.cos(sc.nextDouble());
		System.out.println("Cosine of number is : "+res);
	}

	@Override
	public void tangent() 
	{
		// TODO Auto-generated method stub
		System.out.println("Enter a number : ");
		double res=Math.tan(sc.nextDouble());
		System.out.println("Tangent of number is : "+res);
	}

	@Override
	public void asine() 
	{
		// TODO Auto-generated method stub
		System.out.println("Enter a number : ");
		double res=Math.asin(sc.nextDouble());
		System.out.println("Inverse sine of number is : "+res);
	}

	@Override
	public void acosine() 
	{
		// TODO Auto-generated method stub
		System.out.println("Enter a number : ");
		double res=Math.acos(sc.nextDouble());
		System.out.println("Inverse cosine of number is : "+res);
	}

	@Override
	public void atangent() 
	{
		// TODO Auto-generated method stub
		System.out.println("Enter a number : ");
		double res=Math.atan(sc.nextDouble());
		System.out.println("Inverse tangent of number is : "+res);
	}

	@Override
	public void max()
	{
		// TODO Auto-generated method stub
		System.out.println("Enter two numbers : ");
		double res=Math.max(sc.nextDouble(), sc.nextDouble());
		System.out.println("Maximum is : "+res);
		
	}

	@Override
	public void min()
	{
		// TODO Auto-generated method stub
		System.out.println("Enter two numbers : ");
		double res=Math.min(sc.nextDouble(), sc.nextDouble());
		System.out.println("Minimum is : "+res);
		
	}

	@Override
	public void sqrt() 
	{
		// TODO Auto-generated method stub
		System.out.println("Enter a number : ");
		double res=Math.sqrt(sc.nextDouble());
		System.out.println("Square root of number is : "+res);		
	}

	@Override
	public void cbrt()
	{
		// TODO Auto-generated method stub
		System.out.println("Enter a number : ");
		double res=Math.cbrt(sc.nextDouble());
		System.out.println("Cube root of number is : "+res);		
	}

}
