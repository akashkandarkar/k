
public class Employee 
{
	private int empid;
	private String ename;
	private String dept;

	public Employee(int empid, String ename, String dept) 
	{
		super();
		this.empid = empid;
		this.ename = ename;
		this.dept = dept;
	}

	public int getEmpid() {
		return empid;
	}
	public String getEname() {
		return ename;
	}
	public String getDept() {
		return dept;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + empid;
		return result;
	}
}
