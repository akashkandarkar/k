
public class EmpMain 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Employee e1=new Employee(101, "Pogba", "Man Utd");
		Employee e2=new Employee(101,"Pogba","Man Utd");
		
		//Q1
		if(e1==e2)
		{
			System.out.println("=");
		}
		else
		{
			System.out.println("!=");
		}
		
		//Q2
		if (e1.getEname().equals(e2.getEname()))
		{
			System.out.println("Equals");
		}
		else
		{
			System.out.println("Not equals");
		}
		
		System.out.println(e1.equals(e2));
		System.out.println(e1.hashCode());
		System.out.println(e2.hashCode());
	}

}
